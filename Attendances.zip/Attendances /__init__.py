from . import pre_migration


def active_attendances():
    pre_migration.attendance_pre_migration()
