from upgrade_lib import upgradefunc
from upgrade_lib import upgrade_tools

# Tables to which new columns will be added
ADD_TABLES = {
    "hr_attendance_report",
}

# Columns to add to specific tables
ADD_COLUMNS = {
    "hr_attendance_report": [("company_id", "int")],
}

def process_columns(table_dict, action_func):
    """
    Applies a specified action function to columns in the provided table
    dictionary.

    Args:
        table_dict (dict): A dictionary where keys are table names and values
        are lists of column names.
        action_func (function): The function to apply to each column in the
        tables.
    """
    for table, columns in table_dict.items():
        for column in columns:
            action_func(table, column)

def add_column():
    """
    Add new columns to the tables defined in ADD_TABLES.

    This function iterates over the tables specified in ADD_TABLES and adds the
    columns defined in ADD_COLUMNS using the upgradefunc.Add_column function.

    Parameters:
    None

    Returns:
    None
    """
    for table in ADD_TABLES:
        for column, column_type in ADD_COLUMNS.get(table, []):
            upgradefunc.Add_column(table, column, column_type)

def attendance_pre_migration():
    """
    Perform pre-migration tasks for the Attendance module.

    This function executes the sequence of adding columns, renaming columns,
    dropping columns, and updating column data types as needed.

    Parameters:
    None

    Returns:
    None
    """
    add_column()
