from . import pre_migration


def active_website_blog():
    pre_migration.website_blog_pre_migration()
