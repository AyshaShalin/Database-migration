from upgrade_lib import upgradefunc
from upgrade_lib import upgrade_tools

# Tables where column data types will be updated
UPDT_TABLE_TYPE_CHANGE = {
    "blog_blog",
    "blog_post",
    "blog_tag",
    "blog_tag_category",
}

# Columns and their new types for type change operations
UPDT_TABLE_COLUMN_TYPE_CHANGE = {
    "blog_blog": ["website_meta_title", "website_meta_description",
                  "website_meta_keywords", "seo_name", "name", "subtitle",
                  "content"],
    "blog_post": ["website_meta_title", "website_meta_description",
                  "website_meta_keywords", "seo_name", "name", "subtitle",
                  "content"],
    "blog_tag": ["website_meta_title", "website_meta_description",
                 "website_meta_keywords", "seo_name", "name"],
    "blog_tag_category": ["name"]
}

def process_columns(table_dict, action_func):
    """
    Applies a specified action function to columns in the provided table dictionary.

    Args:
        table_dict (dict): A dictionary where keys are table names and values are lists of column names.
        action_func (function): The function to apply to each column in the tables.
    """
    for table, columns in table_dict.items():
        for column in columns:
            action_func(table, column)

def update_column_type():
    """
    Updates the data type of specified columns in the tables defined in UPDT_TABLE_TYPE_CHANGE.
    """
    process_columns(UPDT_TABLE_COLUMN_TYPE_CHANGE, upgradefunc.change_data_type)

def website_blog_pre_migration():
    """
    Perform pre-migration tasks for the sale module.

    This function executes the sequence of adding columns, renaming columns,
    dropping columns, and updating column data types as needed.

    Parameters:
    None

    Returns:
    None
    """
    update_column_type()
