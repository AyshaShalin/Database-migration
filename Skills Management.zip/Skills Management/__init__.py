from . import pre_migration


def active_skills_management():
    pre_migration.skills_management_pre_migration()
