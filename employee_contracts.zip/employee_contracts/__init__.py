from . import pre_migration


def active_employee_contracts():
    pre_migration.employee_contracts_pre_migration()
