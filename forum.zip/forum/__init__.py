from . import pre_migration


def active_forum():
    pre_migration.forum_pre_migration()
