from . import pre_migration


def active_livechat():
    pre_migration.livechat_pre_migration()
