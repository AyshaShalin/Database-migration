from . import pre_migration


def active_lunch():
    pre_migration.lunch_pre_migration()
