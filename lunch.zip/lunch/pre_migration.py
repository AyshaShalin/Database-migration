from upgrade_lib import upgradefunc
from upgrade_lib import upgrade_tools


# Tables where column data types will be updated
UPDT_TABLE_TYPE_CHANGE = {
    "lunch_alert",
    "lunch_order",
    "lunch_product",
    "lunch_product_category"
}

# Columns and their new types for type change operations
UPDT_TABLE_COLUMN_TYPE_CHANGE = {
    "lunch_alert": ["name", "message"],
    "lunch_order": ["name"],
    "lunch_product": ["name", "description"],
    "lunch_product_category": ["name"]
}

# Tables to which new columns will be added
ADD_TABLES = {
    "lunch_order",
}

# Columns to add to specific tables
ADD_COLUMNS = {
    "lunch_order": [("notified", "boolean")],
}


def process_columns(table_dict, action_func):
    """
    Applies a specified action function to columns in the provided table
    dictionary.

    Args:
        table_dict (dict): A dictionary where keys are table names and values
        are lists of column names.
        action_func (function): The function to apply to each column in the
        tables.
    """
    for table, columns in table_dict.items():
        for column in columns:
            action_func(table, column)


def update_col_type():
    """ Updates the data type of specified columns in the tables defined in
    UPDT_TABLE_TYPE_CHANGE. """
    process_columns(UPDT_TABLE_COLUMN_TYPE_CHANGE,
                    upgradefunc.change_data_type)


def add_column():
    """
    Add new columns to the tables defined in ADD_TABLES.

    This function iterates over the tables specified in ADD_TABLES and adds the
    columns defined in ADD_COLUMNS using the upgradefunc.Add_column function.

    Parameters:
    None

    Returns:
    None
    """
    for table in ADD_TABLES:
        for column, column_type in ADD_COLUMNS.get(table, []):
            upgradefunc.Add_column(table, column, column_type)


def lunch_pre_migration():
    """
    Perform pre-migration tasks for the lunch module.

    This function executes the sequence of adding columns, renaming columns,
    dropping columns, and updating column data types as needed.

    Parameters:
    None

    Returns:
    None
    """
    add_column()
    update_col_type()
