from . import pre_migration
from . import post_migration


def active_repair():
    pre_migration.repair_pre_migration()
