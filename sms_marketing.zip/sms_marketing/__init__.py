from . import pre_migration
from . import post_migration


def active_sms_marketing():
    pre_migration.sms_marketing_pre_migration()
