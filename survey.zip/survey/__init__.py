from . import pre_migration


def active_survey():
    pre_migration.survey_pre_migration()
